declare module "next-auth" {
  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      userType?: "family" | "director" | "venue" | null
      isNewUser?: boolean
      userId?: string
    }
  }

  interface User {
    userType?: "family" | "director" | "venue" | null
    isNewUser?: boolean
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    userType?: "family" | "director" | "venue" | null
    isNewUser?: boolean
    userId?: string
  }
}
