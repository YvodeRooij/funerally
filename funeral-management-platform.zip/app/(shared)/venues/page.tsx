"use client"

import { VenueBrowsing } from "@/components/features/shared/venue-browsing"

export default function VenuesPage() {
  return <VenueBrowsing />
}
