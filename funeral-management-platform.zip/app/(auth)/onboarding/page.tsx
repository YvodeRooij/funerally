"use client"

import { OnboardingRouter } from "@/components/features/auth/onboarding-router"

export default function OnboardingPage() {
  return <OnboardingRouter />
}
