import { FamilyChatInterface } from "@/components/features/communication/family-chat-interface"

export default function FamilyChatPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <FamilyChatInterface />
    </div>
  )
}
