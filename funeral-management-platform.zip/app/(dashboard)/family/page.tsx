import { FamilyDashboard } from "@/components/features/dashboard/family-dashboard"

export default function FamilyDashboardPage() {
  return <FamilyDashboard />
}
