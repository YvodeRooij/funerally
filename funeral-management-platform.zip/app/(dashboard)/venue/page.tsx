import { VenueDashboard } from "@/components/features/dashboard/venue-dashboard"

export default function VenueDashboardPage() {
  return <VenueDashboard />
}
