import { DirectorCalendar } from "@/components/features/calendar/director-calendar"

export default function DirectorCalendarPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <DirectorCalendar />
    </div>
  )
}
