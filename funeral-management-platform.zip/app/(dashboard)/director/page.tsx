import { DirectorDashboard } from "@/components/features/dashboard/director-dashboard"

export default function DirectorDashboardPage() {
  return <DirectorDashboard />
}
