"use client"

import { FamilyChat } from "@/components/features/family/chat"

export default function FamilyChatPage() {
  return <FamilyChat />
}
