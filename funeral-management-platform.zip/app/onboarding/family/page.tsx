"use client"

import { FamilyOnboarding } from "@/components/features/auth/family-onboarding"

export default function FamilyOnboardingPage() {
  return <FamilyOnboarding />
}
