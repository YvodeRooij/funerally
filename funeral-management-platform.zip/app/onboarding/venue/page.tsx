"use client"

import { VenueOnboarding } from "@/components/features/auth/venue-onboarding"

export default function VenueOnboardingPage() {
  return <VenueOnboarding />
}
