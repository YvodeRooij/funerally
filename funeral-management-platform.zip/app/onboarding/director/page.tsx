"use client"

import { DirectorOnboarding } from "@/components/features/auth/director-onboarding"

export default function DirectorOnboardingPage() {
  return <DirectorOnboarding />
}
