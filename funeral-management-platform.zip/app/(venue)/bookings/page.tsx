"use client"

import { VenueBookings } from "@/components/features/venue/bookings"

export default function BookingsPage() {
  return <VenueBookings />
}
