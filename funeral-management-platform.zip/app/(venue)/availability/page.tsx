"use client"

import { VenueAvailability } from "@/components/features/venue/availability"

export default function AvailabilityPage() {
  return <VenueAvailability />
}
