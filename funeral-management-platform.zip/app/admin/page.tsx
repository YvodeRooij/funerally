import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default function AdminPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <AdminDashboard />
    </div>
  )
}
