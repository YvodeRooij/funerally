import type { NextAuthOptions } from "next-auth"
import GoogleProvider from "next-auth/providers/google"

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      if (account && user) {
        // Store user info in JWT token
        token.userType = user.userType || null
        token.isNewUser = !user.userType
        token.userId = user.id
      }
      return token
    },
    async session({ session, token }) {
      // Pass user info to session
      session.user.userType = token.userType as "family" | "director" | "venue" | null
      session.user.isNewUser = token.isNewUser as boolean
      session.user.userId = token.userId as string
      return session
    },
    async signIn({ user, account, profile }) {
      // Always allow sign in
      return true
    },
  },
  pages: {
    signIn: "/auth/signin",
    newUser: "/auth/onboarding",
  },
  session: {
    strategy: "jwt", // Use JWT instead of database sessions
  },
  events: {
    async signIn({ user, account, profile, isNewUser }) {
      if (isNewUser) {
        console.log("New user signed up:", user.email)
      }
    },
  },
}
