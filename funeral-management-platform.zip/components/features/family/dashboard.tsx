"use client"

import { FamilyDashboard as BaseDashboard } from "../dashboard/family-dashboard"

export function FamilyDashboard() {
  return <BaseDashboard />
}
