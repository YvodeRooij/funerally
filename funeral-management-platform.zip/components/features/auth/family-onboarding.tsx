"use client"

import { FamilyOnboarding as BaseOnboarding } from "../family/onboarding"

export function FamilyOnboarding() {
  return <BaseOnboarding />
}
