"use client"

import { VenueOnboarding as BaseOnboarding } from "../venue/onboarding"

export function VenueOnboarding() {
  return <BaseOnboarding />
}
