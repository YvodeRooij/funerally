"use client"

import { VenueAvailability } from "../venue/availability"

export function VenueAvailabilityManager() {
  return <VenueAvailability />
}
