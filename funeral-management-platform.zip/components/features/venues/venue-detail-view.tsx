"use client"

import { VenueDetail } from "../shared/venue-detail"

export function VenueDetailView() {
  return <VenueDetail />
}
