"use client"

import { VenueBrowsing } from "../shared/venue-browsing"

export function VenueBrowsingInterface() {
  return <VenueBrowsing />
}
