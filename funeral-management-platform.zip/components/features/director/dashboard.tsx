"use client"

import { DirectorDashboard as BaseDashboard } from "../dashboard/director-dashboard"

export function DirectorDashboard() {
  return <BaseDashboard />
}
