"use client"

import { ClientDetail } from "../provider/client-detail"

export function ClientDetailView() {
  return <ClientDetail />
}
