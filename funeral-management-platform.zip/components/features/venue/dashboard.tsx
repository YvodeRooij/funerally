"use client"

import { VenueDashboard as BaseDashboard } from "../dashboard/venue-dashboard"

export function VenueDashboard() {
  return <BaseDashboard />
}
