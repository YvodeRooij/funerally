"use client"

import { FamilyChat } from "../family/chat"

export function FamilyChatInterface() {
  return <FamilyChat />
}
