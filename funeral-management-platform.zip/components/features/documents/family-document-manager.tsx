"use client"

import { FamilyDocuments } from "../family/documents"

export function FamilyDocumentManager() {
  return <FamilyDocuments />
}
