"use client"

import { VenueBooking } from "../shared/venue-booking"

export function VenueBookingFlow() {
  return <VenueBooking />
}
