"use client"

import { VenueBookings } from "../venue/bookings"

export function VenueBookingManager() {
  return <VenueBookings />
}
